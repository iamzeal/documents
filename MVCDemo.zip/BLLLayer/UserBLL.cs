﻿using BO;
using DALLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BLLLayer
{
    public class UserBLL
    {
        public void ValidateUser(UserBO objUserBO)
        {
            UserDAL objUserDAL = new UserDAL();

            objUserDAL.ValidateUser(objUserBO);
        }
    }
}
