﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using System.Data.Entity;

namespace DALLayer
{
    public class EmployeeDAL
    {
        public List<EmployeeBO> ViewAllEmployees()
        {
            List<Employee_345994> lstEmployee_345994 = new List<Employee_345994>();            
            List<EmployeeBO> lstEmployeeBO = new List<EmployeeBO>();

            try
            {
                using (var dbContext = new CHN35_MMS206Entities())
                {
                    lstEmployee_345994 = dbContext.Employee_345994.ToList<Employee_345994>();
                }

                foreach (Employee_345994 objEmployee_345994 in lstEmployee_345994)
                {
                    EmployeeBO objEmployeeBO = new EmployeeBO();
                    objEmployeeBO.Empid = objEmployee_345994.Empid;
                    objEmployeeBO.FirstName = objEmployee_345994.FirstName;
                    objEmployeeBO.Gender = objEmployee_345994.Gender;
                    objEmployeeBO.CountryId = objEmployee_345994.CountryId;
                    objEmployeeBO.IsPermanent = objEmployee_345994.IsPermanent.HasValue ? objEmployee_345994.IsPermanent == true : false;
                    objEmployeeBO.LastName = objEmployee_345994.LastName;
                    objEmployeeBO.Salary = objEmployee_345994.Salary.GetValueOrDefault();

                    lstEmployeeBO.Add(objEmployeeBO);
                }
            }
            catch (Exception ex)
            { 
            
            }
            
            return lstEmployeeBO;
        }
        
        public EmployeeBO GetEmployee(int intEmployeeId)
        {
            Employee_345994 objEmployee_345994;

            EmployeeBO objEmployeeBO = new EmployeeBO();

            try
            {
                using (var dbContext = new CHN35_MMS206Entities())
                {
                    objEmployee_345994 = dbContext.Employee_345994.FirstOrDefault<Employee_345994>(e => e.Empid == intEmployeeId);
                }

                if (objEmployee_345994 != null)
                {
                    objEmployeeBO.Empid = objEmployee_345994.Empid;
                    objEmployeeBO.FirstName = objEmployee_345994.FirstName;
                    objEmployeeBO.Gender = objEmployee_345994.Gender;
                    objEmployeeBO.CountryId = objEmployee_345994.CountryId;
                    objEmployeeBO.IsPermanent = objEmployee_345994.IsPermanent.HasValue ? objEmployee_345994.IsPermanent == true : false;
                    objEmployeeBO.LastName = objEmployee_345994.LastName;
                    objEmployeeBO.Salary = objEmployee_345994.Salary.GetValueOrDefault();
                }
            }
            catch (Exception ex)
            { 
            
            }
            return objEmployeeBO;
        }

        public int AddEmployee(EmployeeBO objEmployeeBO)
        {
            Employee_345994 objEmployee_345994 = new Employee_345994();

            try
            {
                objEmployee_345994.FirstName = objEmployeeBO.FirstName;
                objEmployee_345994.LastName = objEmployeeBO.LastName;
                objEmployee_345994.Salary = objEmployeeBO.Salary;
                objEmployee_345994.Gender = objEmployeeBO.Gender;
                objEmployee_345994.IsPermanent = objEmployeeBO.IsPermanent;
                objEmployee_345994.CountryId = objEmployeeBO.CountryId;

                using (var dbContext = new CHN35_MMS206Entities())
                {
                    dbContext.Employee_345994.Add(objEmployee_345994);
                    dbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            { 
            
            }
            return objEmployee_345994.Empid;
        }

        public void UpdateEmployee(EmployeeBO objEmployeeBO)
        {
            Employee_345994 objEmployee_345994 = new Employee_345994();

            try
            {
                using (var dbContext = new CHN35_MMS206Entities())
                {
                    objEmployee_345994 = dbContext.Employee_345994.First(e => e.Empid == objEmployeeBO.Empid);

                    //Option 1: Usage of Current Values and Setting directly EF Object values if the property names are matching with BO Object
                    //dbContext.Entry(objEmployee_345994).CurrentValues.SetValues(objEmployeeBO);
                    //dbContext.Entry(objEmployee_345994).State = EntityState.Modified;
                    //dbContext.SaveChanges();

                    //Option 2: Other way of doing things. Map each and every property values one by one. Use when the property names are not matching b/w BO and EF.
                    objEmployee_345994.FirstName = objEmployeeBO.FirstName;
                    objEmployee_345994.Gender = objEmployeeBO.Gender;
                    objEmployee_345994.CountryId = objEmployeeBO.CountryId;
                    objEmployee_345994.IsPermanent = objEmployeeBO.IsPermanent;
                    objEmployee_345994.LastName = objEmployeeBO.LastName;
                    objEmployee_345994.Salary = objEmployeeBO.Salary;
                    dbContext.SaveChanges();                
                }
            }
            catch (Exception ex)
            { 
            
            }
        }

        public void DeleteEmployee(int intEmployeeId)
        {
            try
            {
                Employee_345994 objEmployee_345994;
                using (var dbContext = new CHN35_MMS206Entities())
                {
                    objEmployee_345994 = dbContext.Employee_345994.First(e => e.Empid == intEmployeeId);

                    dbContext.Entry(objEmployee_345994).State = System.Data.Entity.EntityState.Deleted;

                    dbContext.SaveChanges();
                }
            }
            catch (Exception ex)
            { 
            
            }
        }
    }
}