﻿using BO;   
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DALLayer
{
    public class CountryDAL
    {
        public List<CountryBO> Index()
        {
            List<Countries_345994> lstCountries_345994;
            List<CountryBO> lstCountryBO = new List<CountryBO>();

            try
            {
                using (var context = new CHN35_MMS206Entities())
                {
                    lstCountries_345994 = context.Countries_345994.ToList<Countries_345994>();
                }

                foreach (Countries_345994 objCountry_345994 in lstCountries_345994)
                {
                    CountryBO objCountryBO = new CountryBO();

                    objCountryBO.Id = objCountry_345994.Id;
                    objCountryBO.CountryName = objCountry_345994.CountryName;

                    lstCountryBO.Add(objCountryBO);
                }
            }
            catch (Exception ex)
            { 
            
            }

            return lstCountryBO;
        }
    }
}
