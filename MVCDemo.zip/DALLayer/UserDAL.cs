﻿using BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DALLayer
{
    public class UserDAL
    {
        public void ValidateUser(UserBO objUserBO)
        {
            Users_345994 objUsers_345994 = new Users_345994();

            try
            {
                using (var dbContext = new CHN35_MMS206Entities())
                {
                    objUsers_345994 = dbContext.Users_345994.FirstOrDefault<Users_345994>(u => u.Name == objUserBO.Name && u.Password == objUserBO.Password);
                }

                if (objUsers_345994 != null)
                {
                    objUserBO.Id = objUsers_345994.Id;
                    //objUserBO.Name = objUsers_345994.Name;
                    //objUserBO.Password = objUsers_345994.Password;
                    //objUserBO.RoleId = objUsers_345994.RoleId;
                    objUserBO.IsActive = objUsers_345994.IsActive.HasValue ? objUsers_345994.IsActive.Value : false;
                }
            }
            catch (Exception ex)
            { 
                
            }
        }
    }
}
