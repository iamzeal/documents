﻿using BLLLayer;
using BO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCDemo.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
         [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

         [HttpPost]
         public ActionResult Index(FormCollection frmcollection)
         {
             UserBO objUserBO = new UserBO();
             objUserBO.Name = Request.Form["userid"].ToString();
             objUserBO.Password = Request.Form["password"].ToString();

             UserBLL objUserBLL = new UserBLL();
             objUserBLL.ValidateUser(objUserBO);

             if (objUserBO.IsActive)
             {
                 Session["userid"] = Request.Form["userid"];
                 return Redirect("/Home/Index");
             }
             else
             {
                 ViewBag.Message = "Invalid user id or password";
                 ViewBag.NewMessage = "Testing for invalid user";
             }
             return View();
         }
    }
}