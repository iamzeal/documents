﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCDemo.CustomAttributes
{
    /// <summary>
    /// SessionAuthorizeAttribute is a custom attribute that validates if there is a valid session. It inherits from AuthorizeAttribute class.
    /// If not it redirects to Login Page.
    /// Controllers which needs to check for valid session needs to be decorated with the attribute [SessionAuthorizeAttribute] at the beginning of the class
    /// </summary>
    public class SessionAuthorizeAttribute : AuthorizeAttribute
    {   
        /// <summary>
        /// We are over-riding the default implementation of AuthorizeCore which is a virtual method in the base class.
        /// </summary>
        /// <param name="httpContext">The HTTP context, which encapsulates all HTTP-specific information about an individual HTTP request.</param>
        /// <returns> true if the user is authorized; otherwise, false.</returns>
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            return httpContext.Session["userid"] != null;
        }

        /// <summary>
        /// Processes HTTP requests that fail authorization.
        /// </summary>
        /// <param name="filterContext">Encapsulates the information for using System.Web.Mvc.AuthorizeAttribute.
        ///     The filterContext object contains the controller, HTTP context, request context,
        ///     action result, and route data.
        /// </param>
        protected override void HandleUnauthorizedRequest(AuthorizationContext filterContext)
        {
            filterContext.Result = new RedirectResult("/Login/Index");
        }
    }
}